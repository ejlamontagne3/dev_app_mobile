package com.example.atelier3observerpattern

interface ObservateurChangement {
    fun changement(nouvelleValeur: Int)
}
